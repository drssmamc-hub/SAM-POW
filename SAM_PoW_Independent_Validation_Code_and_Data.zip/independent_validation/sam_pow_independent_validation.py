#!/usr/bin/env python3
"""Independent SAM-PoW research checks.

This is a NEW reference test harness, not the authors' original simulation,
not a production implementation, and not a real TLS exporter demonstration.
It checks deterministic file-dependent proof generation and empirically
estimates attack success by sampling evidence positions rather than drawing
Bernoulli outcomes from the proposed p**(c*(1+r)) bound.

The byte sampler is an HMAC-SHA-256 stream for deterministic testing.
"""
import csv, hashlib, hmac, json, math, os, random, statistics, time
from pathlib import Path

BASE = Path(__file__).resolve().parent
SEED = 20261119
BLOCK=64*1024
FRAGMENT=64

class HMACStream:
    def __init__(self,key): self.key,self.counter=key,0
    def choose(self,n):
        assert n>0
        bound=(1<<256)//n*n
        while True:
            self.counter+=1
            value=int.from_bytes(hmac.new(self.key,self.counter.to_bytes(8,'big'),hashlib.sha256).digest(),'big')
            if value < bound: return value%n

def session_seed(exporter, tag, uid='A', epoch=1, version=1):
    # For modeling only: exporter is a supplied fixture. The TLS exporter API is NOT exercised.
    ctx=json.dumps({'file_tag':tag.hex(),'user':uid,'epoch':epoch,'version':version},sort_keys=True,separators=(',',':')).encode()
    return hmac.new(exporter,b'SAM-PoW/test-only/v1\x00'+ctx,hashlib.sha256).digest()

def selections(seed,nblocks,partitions,c,r,mode='balanced'):
    if c*(1+r)>nblocks: raise ValueError('not enough blocks for nonoverlap')
    s=HMACStream(seed)
    part=lambda b: (b*partitions)//nblocks
    primary=[]; used=set()
    # Rejection sampling from the appropriate pool, not repeated full scans.
    for i in range(c):
        while True:
            if mode=='balanced':
                target=i%partitions
                lo=(target*nblocks+partitions-1)//partitions
                hi=((target+1)*nblocks+partitions-1)//partitions
                b=lo+s.choose(hi-lo)
            elif mode=='hotspot': b=s.choose(max(c,nblocks//4))
            else: b=s.choose(nblocks)
            if b not in used: break
        primary.append(b); used.add(b)
    supports=[]
    for block in primary:
        for _ in range(r):
            while True:
                b=s.choose(nblocks)
                if b not in used and part(b)!=part(block): break
            used.add(b)
            offset=s.choose((BLOCK-FRAGMENT)//FRAGMENT+1)*FRAGMENT
            supports.append((b,offset))
    return primary,supports

def evidence_proof(buf,seed,c,r,partitions=16,mode='balanced'):
    nblocks=len(buf)//BLOCK
    primary,supports=selections(seed,nblocks,partitions,c,r,mode)
    digests=[]
    for i in primary:
        digests.append(hashlib.sha256(b'P'+i.to_bytes(4,'big')+buf[i*BLOCK:(i+1)*BLOCK]).digest())
    for i,off in supports:
        data=buf[i*BLOCK+off:i*BLOCK+off+FRAGMENT]
        digests.append(hashlib.sha256(b'F'+i.to_bytes(4,'big')+off.to_bytes(4,'big')+data).digest())
    return hmac.new(seed,b'SAM-PoW-proof-v1'+c.to_bytes(4,'big')+r.to_bytes(4,'big')+b''.join(digests),hashlib.sha256).digest()

def functional_check():
    buf=os.urandom(64*1024*1024)
    # Tag is a registered file identifier; client must supply the registered tag for a duplicate claim.
    tag=hashlib.sha256(buf).digest(); exporter=os.urandom(32)
    seed=session_seed(exporter,tag)
    p=evidence_proof(buf,seed,16,3)
    assert hmac.compare_digest(p,evidence_proof(buf,seed,16,3))
    # Evidence modification alters proof if the modified block is challenged.
    prim,_=selections(seed,len(buf)//BLOCK,16,16,3)
    changed=bytearray(buf); changed[prim[0]*BLOCK+5]^=0x7f
    assert p!=evidence_proof(changed,seed,16,3)
    changed_contexts={
      'different_exporter':session_seed(os.urandom(32),tag),
      'different_user':session_seed(exporter,tag,uid='B'),
      'new_epoch':session_seed(exporter,tag,epoch=2),
      'new_version':session_seed(exporter,tag,version=2),
      'new_tag':session_seed(exporter,hashlib.sha256(b'not target').digest()),
    }
    outcomes={k: not hmac.compare_digest(p,evidence_proof(buf,v,16,3)) for k,v in changed_contexts.items()}
    assert all(outcomes.values())
    # Two simultaneous context changes (not a general protocol replay proof).
    both=session_seed(exporter,tag,uid='B',version=2)
    outcomes['combined_user_version']=not hmac.compare_digest(p,evidence_proof(buf,both,16,3))
    assert outcomes['combined_user_version']
    return buf,tag,exporter,outcomes

def threat_success(indices,nblocks,partitions,q,knowledge,rng):
    if knowledge=='iid':
        # Independent per-block possession, not an exact-fraction fixed-count sample.
        return all(rng.random()<q for _ in indices)
    if knowledge=='contiguous':
        known=int(q*nblocks); start=rng.randrange(nblocks-known+1)
        return all(start<=i<start+known for i in indices)
    if knowledge=='whole_partition':
        # q=0.95 with partitions=20: exactly one unknown whole partition.
        unknown_count=round((1-q)*partitions)
        unknown=set(rng.sample(range(partitions),unknown_count))
        return all((i*partitions)//nblocks not in unknown for i in indices)
    raise ValueError(knowledge)

def monte_carlo(trials=1500):
    rows=[];nblocks=2000; partitions=20; q=.95
    rng=random.Random(SEED)
    # Each row corresponds to a different adversarial distribution; no analytical p^k draws.
    for mode in ['uniform','balanced','hotspot']:
      for knowledge in ['iid','contiguous','whole_partition']:
       for c in [8,16]:
        for r in [0,1,3]:
         successes=0
         for _ in range(trials):
          streamseed=rng.randbytes(32)
          primary,supports=selections(streamseed,nblocks,partitions,c,r,mode)
          evidence=primary+[b for b,_ in supports]
          successes+=threat_success(evidence,nblocks,partitions,q,knowledge,rng)
         rows.append({'selection':mode,'knowledge':knowledge,'q':q,'primary_c':c,'fragments_r':r,'evidence_blocks':c*(1+r),
                      'trials':trials,'successes':successes,'success_rate':round(successes/trials,5),
                      'ideal_iid_model':round(q**(c*(1+r)),6)})
    with (BASE/'position_sampling_attack_results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return rows

def local_memory_benchmark(buf,tag,exporter,repeat=12):
    rows=[]
    for c in [16,32,64,128]:
      for r in [0,1,3]:
       times=[]
       for it in range(repeat):
        seed=session_seed(exporter,tag,epoch=1+it)
        start=time.perf_counter_ns()
        proof=evidence_proof(buf,seed,c,r)
        assert hmac.compare_digest(proof,evidence_proof(buf,seed,c,r))
        times.append((time.perf_counter_ns()-start)/1e6)
       rows.append({'primary_c':c,'fragments_r':r,'repetitions':repeat,'ram_roundtrip_mean_ms':round(statistics.mean(times),3),
                    'ram_roundtrip_sd_ms':round(statistics.stdev(times),3), 'protocol':'local in-process proof + verify; no TLS/storage/network'})
    with (BASE/'local_ram_proof_benchmark.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return rows

if __name__=='__main__':
    start=time.monotonic()
    buf,tag,exporter,outcomes=functional_check()
    trials=int(os.environ.get('SAM_TRIALS','1500'))
    attack=monte_carlo(trials)
    bench=local_memory_benchmark(buf,tag,exporter)
    out={'functional_context_changes_rejected_in_fixture':outcomes,
         'monte_carlo_rows':len(attack),'monte_carlo_trials_per_config':trials,
         'timing_rows':len(bench),'source':'independent position-sampling plus local in-memory cryptographic fixture',
         'not_included':['real TLS exporter','network','cloud storage','disk contention','multitenant workloads'],
         'execution_wall_seconds':round(time.monotonic()-start,1)}
    (BASE/'validation_summary.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
