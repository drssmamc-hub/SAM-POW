# SAM-PoW Python Simulation Package

This package contains reproducible Python simulation code and generated CSV logs for:

**SAM-PoW: A Session-Bound Adaptive Mosaic Proof of Ownership Technique for Secure Cloud Deduplication**

## Important note

These are **simulation-based analytical results**, not real Azure, Google Cloud, Firebase, or production cloud measurements. Use them in the manuscript as:

**Simulation-Based Results and Discussion**

## How to reproduce

```bash
python sam_pow_simulation.py
```

The simulation uses a fixed random seed (`SEED = 20260707`) for reproducible logs.

## Main CSV logs

- `csv_logs/scalability_raw.csv`
- `csv_logs/scalability_summary.csv`
- `csv_logs/challenge_count_raw.csv`
- `csv_logs/challenge_count_summary.csv`
- `csv_logs/fragment_sensitivity_raw.csv`
- `csv_logs/fragment_sensitivity_summary.csv`
- `csv_logs/partial_attack_summary.csv`
- `csv_logs/near_duplicate_summary.csv`
- `csv_logs/communication_overhead.csv`
- `csv_logs/metadata_overhead.csv`
- `csv_logs/replay_attack_log.csv`

## Figures

The script also generates PNG figures in `figures/` if matplotlib is available.
